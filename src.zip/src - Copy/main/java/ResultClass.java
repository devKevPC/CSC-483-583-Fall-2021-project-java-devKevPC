package edu.arizona.cs;
import org.apache.lucene.document.Document;

public class ResultClass {
    Document DocName;
    double docScore = 0;
}
